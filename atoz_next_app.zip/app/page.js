import dynamic from 'next/dynamic'

// load client component dynamically (no SSR)
const InventoryApp = dynamic(() => import('../components/InventoryApp'), { ssr: false })

export default function Page() {
  return (
    <main>
      <InventoryApp />
    </main>
  )
}
