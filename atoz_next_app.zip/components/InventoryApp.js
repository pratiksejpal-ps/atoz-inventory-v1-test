'use client'
import React, { useState } from 'react'
import useLocalStorage from '../utils/useLocalStorage'

function InventoryForm({ onAdd }){
  const [item,setItem]=useState('')
  const [purchaseQty,setPurchaseQty]=useState('')
  const [soldQty,setSoldQty]=useState('')
  const [mrp,setMrp]=useState('')
  const [cost,setCost]=useState('')

  function submit(e){
    e.preventDefault()
    if(!item) return
    onAdd({
      id: Date.now(),
      itemName: item,
      purchaseQty: Number(purchaseQty||0),
      soldQty: Number(soldQty||0),
      mrp: Number(mrp||0),
      cost: Number(cost||0),
      createdAt: new Date().toISOString()
    })
    setItem('');setPurchaseQty('');setSoldQty('');setMrp('');setCost('')
  }

  return (
    <form className="card" onSubmit={submit}>
      <div style={{display:'grid',gridTemplateColumns:'repeat(5,1fr)',gap:8}} className="grid-5">
        <input placeholder="Item name" value={item} onChange={e=>setItem(e.target.value)} />
        <input placeholder="Purchase Qty" type="number" value={purchaseQty} onChange={e=>setPurchaseQty(e.target.value)} />
        <input placeholder="Sold Qty" type="number" value={soldQty} onChange={e=>setSoldQty(e.target.value)} />
        <input placeholder="MRP" type="number" value={mrp} onChange={e=>setMrp(e.target.value)} />
        <input placeholder="Cost/Unit" type="number" value={cost} onChange={e=>setCost(e.target.value)} />
      </div>
      <div style={{marginTop:10}}> <button className="btn" type="submit">Add / Update Item</button></div>
    </form>
  )
}

function InventoryTable({items,onDelete,onSell}){
  const calcRemaining = (it)=> (it.purchaseQty||0)-(it.soldQty||0)
  const calcProfit = (it)=> (it.soldQty||0)*((it.mrp||0)-(it.cost||0))
  return (
    <div className="card" style={{marginTop:12}}>
      <div style={{overflowX:'auto'}}>
        <table>
          <thead>
            <tr>
              <th>Item</th><th>Purchased</th><th>Sold</th><th>Remaining</th><th>MRP</th><th>Cost</th><th>Profit</th><th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {items.length===0 && <tr><td colSpan={8}>No items yet</td></tr>}
            {items.map(it=> (
              <tr key={it.id}>
                <td>{it.itemName}</td>
                <td>{it.purchaseQty}</td>
                <td>{it.soldQty}</td>
                <td>{calcRemaining(it)}</td>
                <td>₹{it.mrp}</td>
                <td>₹{it.cost}</td>
                <td>₹{calcProfit(it)}</td>
                <td>
                  <button className="btn-green" onClick={()=>onSell(it.id)} style={{marginRight:6}}>Sell 1</button>
                  <button onClick={()=>onDelete(it.id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

export default function InventoryApp(){
  const [items,setItems] = useLocalStorage('atoz_items_v2', [])

  const addOrUpdate = (entry) => {
    setItems(prev => {
      const idx = prev.findIndex(p => p.itemName.trim().toLowerCase() === entry.itemName.trim().toLowerCase())
      if (idx === -1) {
        return [entry, ...prev].slice(0, 1000)
      } else {
        const newArr = [...prev]
        const existing = newArr[idx]
        existing.purchaseQty = (existing.purchaseQty || 0) + (entry.purchaseQty || 0)
        existing.soldQty = (existing.soldQty || 0) + (entry.soldQty || 0)
        existing.mrp = entry.mrp || existing.mrp
        existing.cost = entry.cost || existing.cost
        existing.updatedAt = new Date().toISOString()
        newArr[idx] = existing
        return newArr
      }
    })
  }

  const deleteItem = (id) => setItems(prev => prev.filter(p=>p.id!==id))
  const sellOne = (id) => setItems(prev => prev.map(p=> p.id===id ? {...p, soldQty:(p.soldQty||0)+1} : p))

  return (
    <div className="container">
      <header style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:12}}>
        <h1>A to Z Medical Stores — Inventory (Preview)</h1>
        <div>Preview Mode</div>
      </header>

      <InventoryForm onAdd={addOrUpdate} />
      <InventoryTable items={items} onDelete={deleteItem} onSell={sellOne} />

      <div style={{marginTop:12}} className="card">
        <h3>Notes</h3>
        <p>This is a client-side preview that uses your browser's localStorage. For multi-user syncing and email automation we will add a backend in next updates.</p>
      </div>
    </div>
  )
}
