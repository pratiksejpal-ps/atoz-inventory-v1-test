# A to Z Inventory - Next.js (App Router) Preview

This is a minimal Next.js app-router based preview. It's a client-side demo (no backend) using localStorage so you can deploy quickly to Vercel for preview.

**How to run locally:**

1. `npm install`
2. `npm run dev`

**Deploy to Vercel:** Import this repo and deploy. This uses the `app/` directory (app router).
